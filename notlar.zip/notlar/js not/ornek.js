function Ornek(){
alert("aferin butona bastın");
}